import {
  DarkTheme,
  DefaultTheme,
  Slot,
  ThemeProvider,
  useRouter,
  useSegments,
} from 'expo-router';
import * as SplashScreen from 'expo-splash-screen';
import { useEffect, useState } from 'react';
import { useColorScheme } from 'react-native';

import { AnimatedSplashOverlay } from '@/components/animated-icon';
import AppTabs from '@/components/app-tabs';
import { supabase } from '@/database/supabase';

SplashScreen.preventAutoHideAsync();

export default function TabLayout() {
  const colorScheme = useColorScheme();
  const segments = useSegments();
  const router = useRouter();

  const [sesion, setSesion] = useState<any>(null);
  const [cargando, setCargando] = useState(true);

  useEffect(() => {
    const revisarSesion = async () => {
      const { data } = await supabase.auth.getSession();

      setSesion(data.session);
      setCargando(false);
    };

    revisarSesion();

    const {
      data: { subscription },
    } = supabase.auth.onAuthStateChange((_event, session) => {
      setSesion(session);
    });

    return () => {
      subscription.unsubscribe();
    };
  }, []);

  const estaEnLogin = segments[0] === 'login';

  useEffect(() => {
    if (cargando) return;

    if (!sesion && !estaEnLogin) {
      router.replace('/login');
    }

    if (sesion && estaEnLogin) {
      router.replace('/');
    }
  }, [sesion, cargando, estaEnLogin]);

  if (cargando) {
    return null;
  }

  return (
    <ThemeProvider
      value={colorScheme === 'dark' ? DarkTheme : DefaultTheme}
    >
      <AnimatedSplashOverlay />

      {!sesion && estaEnLogin ? (
        <Slot />
      ) : sesion ? (
        <AppTabs />
      ) : null}
    </ThemeProvider>
  );
}