import { Link, Slot } from 'expo-router';
import { Pressable, StyleSheet, Text, View } from 'react-native';

export default function AppTabs() {
  return (
    <View style={styles.container}>
      <View style={styles.tabs}>
        <Link href="/" asChild>
          <Pressable style={styles.tab}>
            <Text>Inicio</Text>
          </Pressable>
        </Link>

        <Link href="/products" asChild>
          <Pressable style={styles.tab}>
            <Text>Productos</Text>
          </Pressable>
        </Link>

        <Link href="/explore" asChild>
          <Pressable style={styles.tab}>
            <Text>Explore</Text>
          </Pressable>
        </Link>
      </View>

      <View style={styles.content}>
        <Slot />
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },

  tabs: {
    flexDirection: 'row',
    justifyContent: 'center',
    alignItems: 'center',
    paddingVertical: 12,
    borderBottomWidth: 1,
    borderBottomColor: '#ddd',
    gap: 10,
  },

  tab: {
    paddingVertical: 10,
    paddingHorizontal: 20,
  },

  content: {
    flex: 1,
  },
});